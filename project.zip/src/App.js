import Router from "./routes/index";
import "./App.css"
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div>
      <Router />
    </div>
  );
}

export default App;
